<!-- Include jQuery. -->
        <script type="text/javascript" src="jquery-1.9.1.min.js"></script>

        <!-- Include Cloud Zoom CSS. -->
        <link rel="stylesheet" type="text/css" href="cloudzoom.css" />

        <!-- Include Cloud Zoom script. -->
        <script type="text/javascript" src="cloudzoom.js"></script>

        <!-- Call quick start function. -->
        <script type="text/javascript">
            CloudZoom.quickStart();
        </script>
<div class="container">
<div class="row">
<center>
  <div class="col-md-14">
        <h3><b>Nama Barang</b></h3>
        <h5><font color="red">Asal</h5></font>
        <h2><b>Rp. Harga</h2></b>
        <tr>
        <br>
    <div class="thumbnail btn-default">
    	<p><br></p>      
	  <img height="450" class = "cloudzoom" src = "images/large/laravel.png"
             data-cloudzoom = "zoomImage: 'images/large/laravel.png'" />
		<p></p>      	 
      <div class="col-md-12">
		<img height="25%" class = 'cloudzoom-gallery' src = "images/large/laravel.png" data-cloudzoom = "useZoom: '.cloudzoom', image: 'images/large/laravel.png', zoomImage: 'images/large/laravel.png' " >&nbsp;
        <img height="25%" class = 'cloudzoom-gallery' src = "images/large/image2.jpg" data-cloudzoom = "useZoom: '.cloudzoom', image: 'images/large/image2.jpg', zoomImage: 'images/large/image2.jpg' " >&nbsp;
        <img height="25%" class = 'cloudzoom-gallery' src = "images/large/image3.jpg" data-cloudzoom = "useZoom: '.cloudzoom', image: 'images/large/image3.jpg', zoomImage: 'images/large/image3.jpg' " >        
      </div>
      <div class="caption">
      <br>
        <div align="left">
        <p><br></p>
        <h3><b><p style="text-indent: 50px;">Seller : Penjual</p></b></h3>
        <p style="text-indent: 50px;"><b>Keadaan Barang : Baru</p></b>
        <p><br></p>
        <div class="thumbnail center" style="width: 90%;">
        <div class="center" style="width: 95%;">
        <p><br></p>
        <p style="white-space: pre-line;">Desc</p>
        <p><br></p>
        </div>
        </div>
        </div>        
        <div class="thumbnail center" style="width: 45%;">
        <h6>Posted by Anon</h6>
        </center>
        </div>

      </div>
    </div>
  </div>
  </div>
  </div>